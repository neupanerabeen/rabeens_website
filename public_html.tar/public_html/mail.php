<?php
ini_set("SMTP", "mail.rabeens.com");
// ini_set("sendmail_from", "mail.rabeens.com");

$message = "The mail message was sent with the following mail setting:\r\nSMTP = aspmx.l.google.com\r\nsmtp_port = 25\r\nsendmail_from = YourMail@address.com";

$headers = "From: info@rabeens.com";

echo mail("neupanerabeen@gmail.com", "Testing", $message, $headers);
echo "Check your email now....<BR/>";
?>
